<?php
$odd = function ($num) {
    $true = true;
    $false = false;
    if ($num % 2) {
        return $true;
    } else {
        return $false;
    };
};
