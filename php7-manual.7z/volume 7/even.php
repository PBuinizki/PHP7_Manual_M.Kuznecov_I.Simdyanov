<?php
    function Even(int $num)
    {
        if($num % 2) echo "НЕЧЕТНОЕ, СУКА!";
        else echo "Фууух...ЧЕТНОЕ!";
    };