<?php
    require "pow.php";
    echo MyPow(3)."<br>";
    require "even.php";
    Even(4);