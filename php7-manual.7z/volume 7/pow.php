<?php
    function MyPow(int $num) 
    {
        $result = $num*$num;
        return $result;
    };