<?php
    $test_date = date("d.m.Y H:i",mktime(14,10,0,7,10,2018));
    echo "current date format</br>".$test_date."</br>";