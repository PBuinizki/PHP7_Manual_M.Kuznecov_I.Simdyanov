<?php 
    $test_rand=mt_rand(0,1000);
    echo "random digitals</br>".$test_rand;