<?php

/**
 * Вывод версии PHP 
 **/
require "PHP_VERSION.php";
