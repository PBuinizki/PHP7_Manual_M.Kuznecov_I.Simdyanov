<?php
    echo PHP_VERSION;