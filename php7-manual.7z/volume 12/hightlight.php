<?php
highlight_file('hightlight.php');
