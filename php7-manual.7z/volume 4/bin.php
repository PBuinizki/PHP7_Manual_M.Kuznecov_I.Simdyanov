<?php
    $num_1 = 4252;
    $num_2 = 89080;
    echo "Перевод чисел $num_1 и $num_2 в двоичное представление<br>";
    echo decbin($num_1)."<br>";
    echo decbin($num_2)."<br><br>";