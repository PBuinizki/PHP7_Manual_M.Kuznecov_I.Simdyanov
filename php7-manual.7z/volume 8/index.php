<?php
    require_once "hello.php";
    if(hello()) {echo 'Файл успешно записан <br>';}
    if(showHello()){ echo '<br>↑ Cодержимое файла<br>';}
    /* require_once "date_random.php"; */
    require_once "info.php";