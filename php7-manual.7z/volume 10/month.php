<?php
    $content = file('month.txt');
    print_r($content);