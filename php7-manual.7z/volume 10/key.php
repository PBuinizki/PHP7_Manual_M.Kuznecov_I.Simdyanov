<?php
    $arr_2 = ['fst' => 1, 'snd' => 2, 'thd' => 3, 'fth' => 4];
    foreach ($arr_2 as $key => $value)
    {
        echo "<li>$key</li>";
    };