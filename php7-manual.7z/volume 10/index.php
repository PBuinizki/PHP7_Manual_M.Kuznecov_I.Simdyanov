<?php
    echo 'Случайный элемент массива: <br>';
    require_once "rand.php";
    echo '<br><br>Вывод ключей массива:<br>';
    require_once "key.php";
    echo '<br><br>Вывод уникальных элементов массива:<br>';
    require_once "uniq.php";
    echo '<br><br>Обмен между переменным без использования list() и третей переменной:<br>';
    require_once "list.php";
    require_once "rand_sort.php";
    echo '<br><br>Выводим содержимое файла month.txt:<br>';
    require_once "month.php";
