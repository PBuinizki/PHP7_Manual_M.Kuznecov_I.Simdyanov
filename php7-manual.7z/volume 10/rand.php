<?php
    $arr_1 = ['fst','snd','thd','fth'];
    $random = rand(0,3);
    echo $arr_1[$random];