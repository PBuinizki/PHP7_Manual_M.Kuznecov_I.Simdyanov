<?php
    $a = 7;
    $b = 5;
    echo 'a = '.$a.'<br>';
    echo 'b = '.$b.'<br>';
    $a+=+$b-$b=$a;
    echo 'После обмена:<br>';
    echo 'a = '.$a.'<br>';
    echo 'b = '.$b.'<br>';