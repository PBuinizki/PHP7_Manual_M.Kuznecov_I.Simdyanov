<?php
    $arr_3 = ['fst','snd','thd','fth','snd','thd'];
    $result = array_unique($arr_3);
    print_r($result);