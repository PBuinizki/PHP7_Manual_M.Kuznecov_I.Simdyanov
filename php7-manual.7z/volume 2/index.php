<?php
    /**
     *Вывод "Hello, world!"  
     **/
    echo 'Hello, world!<br>';
    /**
     *Вывод параметров о версии PHP"  
    **/
    phpinfo();
